
export default function Home() {
  return (
    <div style={{padding:40,fontFamily:'Arial'}}>
      <h1>Dapperdogs CRM Prototype</h1>
      <p>Your deployment is working.</p>
      <p>Next step: integrate full UI (provided separately).</p>
    </div>
  )
}
